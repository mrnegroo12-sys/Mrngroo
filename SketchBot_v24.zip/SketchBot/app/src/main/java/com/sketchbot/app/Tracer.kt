package com.sketchbot.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.net.Uri

object Tracer {

    class Result(val phases: List<Phase>, val w: Int, val h: Int, val preview: Bitmap, val lineThick: Float = 0f)

    // ---------- تحميل الصورة + قص الهوامش ----------
    class Loaded(
        val bmp: Bitmap,
        val fx0: Float, val fy0: Float, val fw: Float, val fh: Float,
        val aspect: Float
    )

    fun load(ctx: Context, uri: Uri, maxSide: Int): Loaded? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (Math.max(o.outWidth, o.outHeight) / s > 2600) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        val full = ctx.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, o2)
        } ?: return null

        val fwPx = full.width
        val fhPx = full.height
        val box = contentBox(full)
        var x0 = 0
        var y0 = 0
        var x1 = fwPx - 1
        var y1 = fhPx - 1
        if (box != null) { x0 = box[0]; y0 = box[1]; x1 = box[2]; y1 = box[3] }
        val cropped = Bitmap.createBitmap(full, x0, y0, x1 - x0 + 1, y1 - y0 + 1)

        val k = maxSide.toFloat() / Math.max(cropped.width, cropped.height)
        val bmp = if (k < 1f) Bitmap.createScaledBitmap(
            cropped,
            Math.max(1, (cropped.width * k).toInt()),
            Math.max(1, (cropped.height * k).toInt()),
            true
        ) else cropped

        return Loaded(
            bmp,
            x0.toFloat() / fwPx, y0.toFloat() / fhPx,
            (x1 - x0 + 1).toFloat() / fwPx, (y1 - y0 + 1).toFloat() / fhPx,
            fwPx.toFloat() / fhPx
        )
    }

    private fun contentBox(src: Bitmap): IntArray? {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = px[y * w + x]
                val al = Color.alpha(c)
                if (al < 20) continue
                val cr0 = (Color.red(c) * al + 255 * (255 - al)) / 255
                val cg0 = (Color.green(c) * al + 255 * (255 - al)) / 255
                val cb0 = (Color.blue(c) * al + 255 * (255 - al)) / 255
                if (cr0 < 240 || cg0 < 240 || cb0 < 240) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return null
        val pad = 16
        return intArrayOf(
            Math.max(0, minX - pad), Math.max(0, minY - pad),
            Math.min(w - 1, maxX + pad), Math.min(h - 1, maxY + pad)
        )
    }

    private fun grad(c: IntArray, i: Int, w: Int): Int {
        val gx = -c[i - w - 1] + c[i - w + 1] - 2 * c[i - 1] + 2 * c[i + 1] - c[i + w - 1] + c[i + w + 1]
        val gy = -c[i - w - 1] - 2 * c[i - w] - c[i - w + 1] + c[i + w - 1] + 2 * c[i + w] + c[i + w + 1]
        return Math.abs(gx) + Math.abs(gy)
    }

    private fun morph(src: BooleanArray, w: Int, h: Int, r: Int, erode: Boolean): BooleanArray {
        val tmp = BooleanArray(w * h)
        val out = BooleanArray(w * h)
        val pre = IntArray(Math.max(w, h) + 1)
        val full = 2 * r + 1
        for (y in 0 until h) {
            pre[0] = 0
            for (x in 0 until w) pre[x + 1] = pre[x] + (if (src[y * w + x]) 1 else 0)
            for (x in 0 until w) {
                val a = Math.max(0, x - r)
                val b = Math.min(w - 1, x + r)
                val c = pre[b + 1] - pre[a]
                tmp[y * w + x] = if (erode) c == full else c > 0
            }
        }
        for (x in 0 until w) {
            pre[0] = 0
            for (y in 0 until h) pre[y + 1] = pre[y] + (if (tmp[y * w + x]) 1 else 0)
            for (y in 0 until h) {
                val a = Math.max(0, y - r)
                val b = Math.min(h - 1, y + r)
                val c = pre[b + 1] - pre[a]
                out[y * w + x] = if (erode) c == full else c > 0
            }
        }
        return out
    }

    /**
     * threshold : حد السواد لخطوط الحدود
     * detail    : 0 = حدود سوداء فقط، وكلما زاد ظهرت خطوط التفاصيل الدقيقة
     * fillGap   : المسافة بين خطوط التلوين (حسب سمك فرشاتك)
     * colors    : عدد الألوان، و0 = رسم خطوط فقط بلا تلوين
     */
    @Volatile private var snakeMode = true

    fun process(src: Bitmap, threshold: Int, detail: Int, fillGap: Int, colors: Int, fill: Boolean = true, soft: Int = 0, blend: Boolean = false, snake: Boolean = true, pockets: Boolean = true): Result {
        snakeMode = snake
        val w = src.width
        val h = src.height
        val n = w * h
        val px = IntArray(n)
        src.getPixels(px, 0, w, 0, 0, w, h)

        val rr = IntArray(n)
        val gg = IntArray(n)
        val bb = IntArray(n)
        val lum = IntArray(n)
        for (i in 0 until n) {
            val c = px[i]
            val al = Color.alpha(c)
            if (al < 8) {
                rr[i] = 255; gg[i] = 255; bb[i] = 255; lum[i] = 255
            } else {
                // الشفافية: يُدمج اللون مع الأبيض فيظهر بنفس مظهره الحقيقي على الكانفس
                if (al == 255) {
                    rr[i] = Color.red(c); gg[i] = Color.green(c); bb[i] = Color.blue(c)
                } else {
                    rr[i] = (Color.red(c) * al + 255 * (255 - al)) / 255
                    gg[i] = (Color.green(c) * al + 255 * (255 - al)) / 255
                    bb[i] = (Color.blue(c) * al + 255 * (255 - al)) / 255
                }
                lum[i] = (0.299 * rr[i] + 0.587 * gg[i] + 0.114 * bb[i]).toInt()
            }
        }

        val dark = BooleanArray(n)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            dark[i] = lum[i] < threshold
        }

        // مساحات داكنة سميكة (عيون، ظلال كبيرة)
        val rad0 = Math.max(5, Math.max(w, h) / 130)
        val region = BooleanArray(n)
        val lineDark = BooleanArray(n)
        if (colors > 0) {
            // كشف الخط بالتباين مع الجوار (لا بعتبة سواد ثابتة): الخط = بكسل أغمق بوضوح من محيطه
            // فيلتقط الخطوط البنية/الداكنة الباهتة كاملة، ولا يلتقط ظلال الماء والصخور الداكنة
            val lbl = boxBlur(boxBlur(lum, w, h), w, h)
            val integ = IntArray((w + 1) * (h + 1))
            for (y in 0 until h) {
                var rowSum = 0
                for (x in 0 until w) {
                    rowSum += lbl[y * w + x]
                    integ[(y + 1) * (w + 1) + (x + 1)] = integ[y * (w + 1) + (x + 1)] + rowSum
                }
            }
            val br = 8
            val limit = threshold + 60
            val cand = BooleanArray(n)
            for (y in 0 until h) {
                for (x in 0 until w) {
                    val i = y * w + x
                    if (lbl[i] >= limit) continue
                    val x0 = Math.max(0, x - br)
                    val y0 = Math.max(0, y - br)
                    val x1 = Math.min(w, x + br + 1)
                    val y1 = Math.min(h, y + br + 1)
                    val sum = integ[y1 * (w + 1) + x1] - integ[y0 * (w + 1) + x1] - integ[y1 * (w + 1) + x0] + integ[y0 * (w + 1) + x0]
                    val mean = sum / ((x1 - x0) * (y1 - y0))
                    if (mean - lbl[i] > 30) cand[i] = true
                }
            }
            val thick = morph(cand, w, h, rad0, true)
            val opened = morph(thick, w, h, rad0, false)
            val line0 = BooleanArray(n)
            for (i in 0 until n) {
                region[i] = opened[i] && cand[i]
                line0[i] = cand[i] && !opened[i]
            }
            // سدّ الفجوات الصغيرة ثم حذف البقع الصغيرة
            val closed = morph(morph(line0, w, h, 2, false), w, h, 2, true)
            val cl = IntArray(n) { if (closed[it]) 1 else -1 }
            val cpl = components(cl, w, h)
            for (i in 0 until n) {
                val c = cpl.id[i]
                lineDark[i] = c >= 0 && cpl.area[c] >= 25
            }
        } else {
            val thick = morph(dark, w, h, rad0, true)
            val opened = morph(thick, w, h, rad0, false)
            for (i in 0 until n) {
                region[i] = opened[i] && dark[i]
                lineDark[i] = dark[i] && !region[i]
            }
        }

        // ---------- الخطوط ----------
        val mask = lineDark.copyOf()
        if (detail > 0 && colors == 0) {
            val t = Math.max(15, 115 - detail)
            val rad = 4
            for (y in rad until h - rad) {
                for (x in rad until w - rad) {
                    val i = y * w + x
                    if (dark[i]) continue
                    val m = Math.max(grad(rr, i, w), Math.max(grad(gg, i, w), grad(bb, i, w))) / 4
                    if (m <= t) continue
                    var near = false
                    var yy = -rad
                    while (yy <= rad && !near) {
                        var xx = -rad
                        while (xx <= rad) {
                            if (dark[i + yy * w + xx]) { near = true; break }
                            xx++
                        }
                        yy++
                    }
                    if (!near) mask[i] = true
                }
            }
        }
        var darkCnt = 0
        for (i in 0 until n) if (mask[i]) darkCnt++
        thin(mask, w, h)
        var skelCnt = 0
        for (i in 0 until n) if (mask[i]) skelCnt++
        val lineThick = if (skelCnt > 0) darkCnt.toFloat() / skelCnt else 0f
        val outline = ArrayList<List<PointF>>()
        for (s0 in trace(mask, w, h)) outline.add(smoothPath(s0, 5))

        // لون الخطوط = متوسط ألوان البكسلات الداكنة
        var sr = 0L
        var sg = 0L
        var sb = 0L
        var sc = 0L
        for (i in 0 until n) if (lineDark[i]) { sr += rr[i]; sg += gg[i]; sb += bb[i]; sc++ }
        val outColor = if (sc > 200) Color.rgb((sr / sc).toInt(), (sg / sc).toInt(), (sb / sc).toInt())
        else Color.rgb(30, 30, 30)

        val gap = Math.max(1, fillGap)
        val phases = ArrayList<Phase>()
        var labels: IntArray? = null
        var dFill: List<List<PointF>> = emptyList()
        var centers = IntArray(0)

        if (colors > 0) {
            // ---------- التلوين ----------
            val bg = background(rr, gg, bb, w, h, pockets)
            // استبعاد البكسلات المجاورة للخطوط (حوافها المتدرجة تنتج ألواناً رمادية غير موجودة في التصميم)
            val nearLine = morph(lineDark, w, h, 3, false)
            // الهالة: بكسلات حافة الخط الملامسة للخلفية تصبح خلفية (لا تأخذ لون الجسم فتظهر كإطار شاحب خارج الخط)
            val bgNear = morph(bg, w, h, 3, false)
            for (i in 0 until n) if (!bg[i] && bgNear[i] && nearLine[i] && !lineDark[i]) bg[i] = true
            val valid = BooleanArray(n) { !bg[it] && !lineDark[it] && !nearLine[it] }
            val q = mergeClose(quantize(rr, gg, bb, valid, colors), n, 10)
            var lb = q.labels
            val k = q.centers.size
            lb = smooth(lb, w, h, k, 2)
            lb = smooth(lb, w, h, k, 2)
            lb = smooth(lb, w, h, k, 3)
            spread(lb, bg, w, h)
            labels = lb
            centers = q.centers
            // الخطوط الداكنة السميكة تُملأ كمنطقة لون مستقلة (تُرسم أخيراً فوق الألوان)

            if (fill) {
                // ---------- وضع Fill: حدود كل منطقة + نقطة ضغط بأداة التعبئة ----------
                val minArea = Math.max(60, n / 15000)
                lb = cleanSmall(lb, w, h, k, minArea)
                labels = lb
                val plan = fillPlan(lb, w, h, k, gap)
                val area = IntArray(k)
                for (i in 0 until n) if (lb[i] >= 0) area[lb[i]]++
                val order = (0 until k).filter { plan.strokes[it].isNotEmpty() || plan.seeds[it].isNotEmpty() }
                    .sortedByDescending { area[it] }
                for ((idx, c) in order.withIndex()) {
                    val sd = plan.seeds[c]
                    val px = if (sd.isNotEmpty()) sd[0].x else -1f
                    val py = if (sd.isNotEmpty()) sd[0].y else -1f
                    phases.add(
                        Phase(centers[c], "لون ${idx + 1} من ${order.size}", plan.strokes[c], true, px, py, ArrayList(sd))
                    )
                }
            } else {
                // ---------- وضع الفرشاة الدقيق ----------
                val minArea = Math.max(60, n / 15000)
                lb = cleanSmall(lb, w, h, k, minArea)
                labels = lb
                val sk = brushPlan(lb, w, h, k, gap, soft)
                val area = IntArray(k)
                for (i in 0 until n) if (lb[i] >= 0) area[lb[i]]++
                val order = (0 until k).filter { sk[it].isNotEmpty() }.sortedByDescending { area[it] }
                for ((idx, c) in order.withIndex()) {
                    val pp = pickPoint(lb, c, w, h)
                    phases.add(Phase(centers[c], "لون ${idx + 1} من ${order.size}", sk[c], true, pp.x, pp.y))
                }
                if (blend) {
                    val bs = blendStrokes(lb, nearLine, w, h, gap)
                    if (bs.isNotEmpty()) phases.add(Phase(Color.WHITE, "تنعيم الحدود بين الألوان", bs, true, blend = true))
                }
            }
        } else {
            outline.addAll(hatch(region, w, h, gap))
        }
        var op = PointF(-1f, -1f)
        for (st in outline) {
            if (st.size >= 15) {
                val mid = st[st.size / 2]
                val xi = mid.x.toInt()
                val yi = mid.y.toInt()
                if (xi in 0 until w && yi in 0 until h && lineDark[yi * w + xi]) { op = PointF(mid.x, mid.y); break }
            }
        }
        if (op.x < 0f) {
            for (i in 0 until n) if (lineDark[i]) { op = PointF(i % w + 0.5f, i / w + 0.5f); break }
        }
        var multi = false
        if (colors > 0) {
            // تصنيف الخطوط إلى 3 ألوان على الأكثر (أسود للتاج، بني للقشرة...) بدل لون واحد للجميع
            val q2 = mergeClose(quantize(rr, gg, bb, lineDark, 3), n, 10)
            if (q2.centers.isNotEmpty()) {
                val groups = Array(q2.centers.size) { ArrayList<List<PointF>>() }
                for (st in outline) {
                    val votes = IntArray(q2.centers.size)
                    for (p in st) {
                        val ix = p.x.toInt().coerceIn(0, w - 1)
                        val iy = p.y.toInt().coerceIn(0, h - 1)
                        val l = q2.labels[iy * w + ix]
                        if (l >= 0) votes[l]++
                    }
                    var b = 0
                    for (j in votes.indices) if (votes[j] > votes[b]) b = j
                    groups[b].add(st)
                }
                for (j in groups.indices) {
                    if (groups[j].isEmpty()) continue
                    phases.add(Phase(q2.centers[j], "الخطوط ${j + 1}", groups[j], false, op.x, op.y))
                    multi = true
                }
            }
        }
        if (!multi) {
            val outStrokes = ArrayList<List<PointF>>()
            outStrokes.addAll(dFill)
            outStrokes.addAll(outline)
            phases.add(Phase(outColor, "الخطوط الخارجية", outStrokes, false, op.x, op.y))
        }

        // ---------- المعاينة ----------
        val prev = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val fl = labels
        if (fl != null) {
            val img = IntArray(n)
            for (i in 0 until n) {
                val l = fl[i]
                img[i] = if (lineDark[i]) outColor else if (l >= 0) (0xFF000000.toInt() or centers[l]) else Color.WHITE
            }
            prev.setPixels(img, 0, w, 0, 0, w, h)
        } else {
            prev.eraseColor(Color.WHITE)
        }
        val cv = Canvas(prev)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (fl != null) outColor else Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.4f
        }
        for (st in outline) {
            if (st.size < 2) continue
            val p = Path()
            p.moveTo(st[0].x, st[0].y)
            for (k2 in 1 until st.size) p.lineTo(st[k2].x, st[k2].y)
            cv.drawPath(p, paint)
        }
        return Result(phases, w, h, prev, lineThick)
    }



    // تمويه 3x3 سريع
    private fun boxBlur(src: IntArray, w: Int, h: Int): IntArray {
        val n = w * h
        val tmp = IntArray(n)
        val out = IntArray(n)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            tmp[i] = (src[y * w + Math.max(x - 1, 0)] + src[i] + src[y * w + Math.min(x + 1, w - 1)]) / 3
        }
        for (y in 0 until h) for (x in 0 until w) {
            out[y * w + x] = (tmp[Math.max(y - 1, 0) * w + x] + tmp[y * w + x] + tmp[Math.min(y + 1, h - 1) * w + x]) / 3
        }
        return out
    }

    // تنعيم مسار (متوسط متحرك) مع تثبيت الطرفين، فتزول التعرجات الشبكية
    private fun smoothPath(pts: List<PointF>, passes: Int): List<PointF> {
        var cur = pts
        for (p in 0 until passes) {
            if (cur.size < 5) break
            val out = ArrayList<PointF>(cur.size)
            out.add(cur[0])
            for (i in 1 until cur.size - 1) {
                out.add(PointF((cur[i - 1].x + 2f * cur[i].x + cur[i + 1].x) / 4f, (cur[i - 1].y + 2f * cur[i].y + cur[i + 1].y) / 4f))
            }
            out.add(cur[cur.size - 1])
            cur = out
        }
        return cur
    }

    // ---------- مناطق متصلة بنفس اللون ----------
    private class Comps(val id: IntArray, val label: IntArray, val area: IntArray)

    private fun components(lb: IntArray, w: Int, h: Int): Comps {
        val n = w * h
        val id = IntArray(n) { -1 }
        val q = IntArray(n)
        val labs = ArrayList<Int>()
        val areas = ArrayList<Int>()
        for (s in 0 until n) {
            if (lb[s] < 0 || id[s] >= 0) continue
            val c = labs.size
            val l = lb[s]
            var head = 0
            var tail = 0
            q[tail++] = s
            id[s] = c
            while (head < tail) {
                val i = q[head++]
                val x = i % w
                val y = i / w
                if (x > 0 && id[i - 1] < 0 && lb[i - 1] == l) { id[i - 1] = c; q[tail++] = i - 1 }
                if (x < w - 1 && id[i + 1] < 0 && lb[i + 1] == l) { id[i + 1] = c; q[tail++] = i + 1 }
                if (y > 0 && id[i - w] < 0 && lb[i - w] == l) { id[i - w] = c; q[tail++] = i - w }
                if (y < h - 1 && id[i + w] < 0 && lb[i + w] == l) { id[i + w] = c; q[tail++] = i + w }
            }
            labs.add(l)
            areas.add(tail)
        }
        return Comps(id, labs.toIntArray(), areas.toIntArray())
    }

    // دمج المناطق الصغيرة جداً في أكثر جار لها حتى لا تبقى بقع بيضاء أو حدود كثيرة
    private fun cleanSmall(lb: IntArray, w: Int, h: Int, k: Int, minArea: Int): IntArray {
        val cp = components(lb, w, h)
        val n = w * h
        val votes = HashMap<Int, IntArray>()
        for (i in 0 until n) {
            val c = cp.id[i]
            if (c < 0 || cp.area[c] >= minArea) continue
            val v = votes.getOrPut(c) { IntArray(k) }
            val x = i % w
            val y = i / w
            if (x > 0 && lb[i - 1] >= 0 && lb[i - 1] != lb[i]) v[lb[i - 1]]++
            if (x < w - 1 && lb[i + 1] >= 0 && lb[i + 1] != lb[i]) v[lb[i + 1]]++
            if (y > 0 && lb[i - w] >= 0 && lb[i - w] != lb[i]) v[lb[i - w]]++
            if (y < h - 1 && lb[i + w] >= 0 && lb[i + w] != lb[i]) v[lb[i + w]]++
        }
        val target = HashMap<Int, Int>()
        for ((c, v) in votes) {
            var b = -1
            var bc = 0
            for (l in 0 until k) if (v[l] > bc) { bc = v[l]; b = l }
            target[c] = b
        }
        val out = lb.copyOf()
        for (i in 0 until n) {
            val c = cp.id[i]
            if (c < 0) continue
            val t = target[c]
            if (t != null) out[i] = t
        }
        return out
    }

    private class FillPlan(
        val strokes: Array<ArrayList<List<PointF>>>,
        val seeds: Array<ArrayList<PointF>>,
        val areas: Array<ArrayList<Float>>,
        val fallback: Array<ArrayList<List<List<PointF>>>>
    )

    /**
     * لكل منطقة: حلقات الحدود (تُرسم بلون المنطقة فتصبح مغلقة) + نقطة في أعمق مكان داخلها
     * ليضغط عندها البوت بأداة Fill. المناطق الرفيعة التي تغطيها الفرشاة نفسها لا تحتاج ضغطة.
     */
    private fun fillPlan(lb: IntArray, w: Int, h: Int, k: Int, gap: Int): FillPlan {
        val n = w * h
        val cp = components(lb, w, h)
        val id = cp.id
        val bd = BooleanArray(n)
        val dist = IntArray(n) { -1 }
        val q = IntArray(n)
        var tail = 0
        for (i in 0 until n) {
            val c = id[i]
            if (c < 0) continue
            val x = i % w
            val y = i / w
            val edge = x == 0 || y == 0 || x == w - 1 || y == h - 1 ||
                id[i - 1] != c || id[i + 1] != c || id[i - w] != c || id[i + w] != c
            if (edge) { bd[i] = true; dist[i] = 0; q[tail++] = i }
        }
        val cn = cp.area.size
        val best = IntArray(cn) { -1 }
        val seedPix = IntArray(cn) { -1 }
        var head = 0
        while (head < tail) {
            val i = q[head++]
            val c = id[i]
            val d = dist[i]
            if (d > best[c]) { best[c] = d; seedPix[c] = i }
            val x = i % w
            val y = i / w
            if (x > 0 && id[i - 1] == c && dist[i - 1] < 0) { dist[i - 1] = d + 1; q[tail++] = i - 1 }
            if (x < w - 1 && id[i + 1] == c && dist[i + 1] < 0) { dist[i + 1] = d + 1; q[tail++] = i + 1 }
            if (y > 0 && id[i - w] == c && dist[i - w] < 0) { dist[i - w] = d + 1; q[tail++] = i - w }
            if (y < h - 1 && id[i + w] == c && dist[i + w] < 0) { dist[i + w] = d + 1; q[tail++] = i + w }
        }
        val strokes = Array(k) { ArrayList<List<PointF>>() }
        val seeds = Array(k) { ArrayList<PointF>() }
        val areas = Array(k) { ArrayList<Float>() }
        val fallback = Array(k) { ArrayList<List<List<PointF>>>() }
        val seedComp = Array(k) { ArrayList<Int>() }
        // إطار سميك مانع للتسرب: حلقات متداخلة على أعماق 0 و gap و 2*gap داخل كل منطقة
        // (تُستعمل الحلقة الأعمق فقط إن بقي داخل المنطقة فراغ كافٍ للتعبئة)
        val g = Math.max(1, gap)
        val lastLevel = IntArray(cn)
        for (c in 0 until cn) {
            var m = 0
            if (best[c] > g + g) m = g
            if (best[c] > 2 * g + g) m = 2 * g
            lastLevel[c] = m
            if (best[c] > m + g && seedPix[c] >= 0) {
                val p = seedPix[c]
                seeds[cp.label[c]].add(PointF(p % w + 0.5f, p / w + 0.5f))
                areas[cp.label[c]].add(cp.area[c].toFloat())
                seedComp[cp.label[c]].add(c)
            }
        }
        for (lv in intArrayOf(0, g, 2 * g)) {
            val mask = BooleanArray(n)
            var any = false
            for (i in 0 until n) {
                val c = id[i]
                if (c < 0 || dist[i] != lv || lv > lastLevel[c]) continue
                mask[i] = true
                any = true
            }
            if (!any) continue
            for (cs in traceLoops(mask, id, w, h)) strokes[cp.label[cs.comp]].add(cs.pts)
        }
        // ---------- تحقق داخلي من إغلاق الحلقات (بلا لقطات شاشة) ----------
        // نرسم الحلقات في خريطة بسمك محافظ (أقل من سمك الفرشاة الفعلي) ثم نحاكي تعبئة 8-اتجاهات من نقطة الضغط.
        // إن خرجت التعبئة من المنطقة فالحلقة غير مغلقة: لا Fill، وتُلوَّن المنطقة بالفرشاة بدلاً منه.
        val rad = Math.max(1, Math.round(g * 0.3f))
        val qf = IntArray(n)
        for (lab in 0 until k) {
            if (seeds[lab].isEmpty()) continue
            val band = BooleanArray(n)
            for (st in strokes[lab]) {
                for (si in 0 until st.size - 1) {
                    val a = st[si]
                    val b = st[si + 1]
                    val len = Math.hypot((b.x - a.x).toDouble(), (b.y - a.y).toDouble()).toFloat()
                    val steps = Math.max(1, (len / 0.7f).toInt())
                    for (s in 0..steps) {
                        val cx = Math.round(a.x + (b.x - a.x) * s / steps - 0.5f)
                        val cy = Math.round(a.y + (b.y - a.y) * s / steps - 0.5f)
                        for (dy in -rad..rad) for (dx in -rad..rad) {
                            val xx = cx + dx
                            val yy = cy + dy
                            if (xx in 0 until w && yy in 0 until h) band[yy * w + xx] = true
                        }
                    }
                }
            }
            val keepSeeds = ArrayList<PointF>()
            val keepAreas = ArrayList<Float>()
            for (si in seeds[lab].indices) {
                val sp = seeds[lab][si]
                val c = seedComp[lab][si]
                val s0 = sp.y.toInt() * w + sp.x.toInt()
                var ok = !band[s0]
                if (ok) {
                    val cap = (cp.area[c] * 1.1f + 50f).toInt()
                    val seen = HashSet<Int>()
                    var hd = 0
                    var tl = 0
                    qf[tl++] = s0
                    seen.add(s0)
                    while (hd < tl && ok) {
                        val i = qf[hd++]
                        val x = i % w
                        val y = i / w
                        if (x == 0 || y == 0 || x == w - 1 || y == h - 1) { ok = false; break }
                        for (dy in -1..1) for (dx in -1..1) {
                            if (dx == 0 && dy == 0) continue
                            val j = i + dy * w + dx
                            if (band[j] || seen.contains(j)) continue
                            seen.add(j)
                            if (tl >= cap || tl >= qf.size) { ok = false } else qf[tl++] = j
                        }
                    }
                }
                if (ok) { keepSeeds.add(sp); keepAreas.add(areas[lab][si]) }
                else strokes[lab].addAll(scribble(id, c, w, h, g))
            }
            seeds[lab].clear(); seeds[lab].addAll(keepSeeds)
            areas[lab].clear(); areas[lab].addAll(keepAreas)
        }
        return FillPlan(strokes, seeds, areas, fallback)
    }


    /**
     * تلوين بالفرشاة فقط وبدقة: لكل منطقة حلقة حدود مركزها على عمق نصف سمك الفرشاة
     * (فتلامس حافتها الخارجية حد المنطقة تماماً دون أن تتجاوزه)، ثم يُملأ الداخل بخطوط متقاربة.
     */
    private fun brushPlan(lb: IntArray, w: Int, h: Int, k: Int, gap: Int, soft: Int): Array<ArrayList<List<PointF>>> {
        val n = w * h
        val cp = components(lb, w, h)
        val id = cp.id
        val dist = IntArray(n) { -1 }
        val q = IntArray(n)
        var tail = 0
        for (i in 0 until n) {
            val c = id[i]
            if (c < 0) continue
            val x = i % w
            val y = i / w
            val edge = x == 0 || y == 0 || x == w - 1 || y == h - 1 ||
                id[i - 1] != c || id[i + 1] != c || id[i - w] != c || id[i + w] != c
            if (edge) { dist[i] = 0; q[tail++] = i }
        }
        val cn = cp.area.size
        val best = IntArray(cn) { -1 }
        var head = 0
        while (head < tail) {
            val i = q[head++]
            val c = id[i]
            val d = dist[i]
            if (d > best[c]) best[c] = d
            val x = i % w
            val y = i / w
            if (x > 0 && id[i - 1] == c && dist[i - 1] < 0) { dist[i - 1] = d + 1; q[tail++] = i - 1 }
            if (x < w - 1 && id[i + 1] == c && dist[i + 1] < 0) { dist[i + 1] = d + 1; q[tail++] = i + 1 }
            if (y > 0 && id[i - w] == c && dist[i - w] < 0) { dist[i - w] = d + 1; q[tail++] = i - w }
            if (y < h - 1 && id[i + w] == c && dist[i + w] < 0) { dist[i + w] = d + 1; q[tail++] = i + w }
        }
        // عمق حلقة الحدود لكل منطقة (نصف قطر الفرشاة تقريباً، وأقل منه في المناطق الرفيعة)
        // soft=0: حواف حادة تماماً داخل المنطقة. soft=10: مركز الفرشاة على الحد فتتداخل الألوان بنعومة
        val r = Math.max(0, Math.round(gap * 0.55f * (10 - soft) / 10f))
        val lv = IntArray(cn) { Math.min(r, best[it] / 2) }
        // تلوين بحلقات متحدة المركز: من الحد إلى الداخل بخطوة ثابتة، فتتبع كل ضربة شكل المنطقة (لا صفوف ولا خطوط)
        val step = Math.max(3, gap)
        val lastLv = IntArray(cn) { c ->
            if (best[c] < lv[c]) lv[c] else lv[c] + ((best[c] - lv[c]) / step) * step
        }
        val ring = BooleanArray(n)
        val core = IntArray(n) { -1 }
        for (i in 0 until n) {
            val c = id[i]
            if (c < 0) continue
            val d = dist[i]
            if (d >= lv[c] && d <= lastLv[c] && (d - lv[c]) % step == 0) ring[i] = true
            // ما تبقى في المركز بعد آخر حلقة (إن كان أوسع من نصف الخطوة) يُغطّى بخطوط قصيرة
            if (d > lastLv[c] + step / 2) core[i] = cp.label[c]
        }
        val strokes = Array(k) { ArrayList<List<PointF>>() }
        for (cs in traceLoops(ring, id, w, h)) strokes[cp.label[cs.comp]].add(smoothPath(cs.pts, 3))
        for (c in 0 until k) strokes[c].addAll(scribble(core, c, w, h, gap))
        return strokes
    }


    /**
     * ضربات تنعيم قصيرة (لأداة Smudge) عمودية على الحدود بين منطقتين لونيتين متجاورتين،
     * تتجاهل الحدود المخبّأة تحت الخطوط الخارجية.
     */
    private fun blendStrokes(lb: IntArray, near: BooleanArray, w: Int, h: Int, gap: Int): List<List<PointF>> {
        val s = Math.max(10, gap * 6)
        val len = Math.max(3f, gap * 2.5f)
        val cw = (w + s - 1) / s
        val cells = HashSet<Int>()
        val out = ArrayList<List<PointF>>()
        for (y in 3 until h - 3) for (x in 3 until w - 3) {
            val i = y * w + x
            val a = lb[i]
            if (a < 0) continue
            val r = lb[i + 1]
            val d = lb[i + w]
            val other = if (r >= 0 && r != a) r else if (d >= 0 && d != a) d else -1
            if (other < 0) continue
            if (near[i] || near[i + 1] || near[i + w]) continue
            if (!cells.add((y / s) * cw + (x / s))) continue
            var nx = 0f
            var ny = 0f
            for (dy in -3..3) for (dx in -3..3) {
                val l = lb[(y + dy) * w + (x + dx)]
                if (l == other) { nx += dx; ny += dy } else if (l == a) { nx -= dx; ny -= dy }
            }
            val m = Math.sqrt((nx * nx + ny * ny).toDouble()).toFloat()
            if (m < 1e-3f) continue
            nx /= m
            ny /= m
            val x0 = x + 0.5f - nx * len
            val y0 = y + 0.5f - ny * len
            val x1 = x + 0.5f + nx * len
            val y1 = y + 0.5f + ny * len
            if (x0 < 0f || y0 < 0f || x1 < 0f || y1 < 0f || x0 > w - 1f || x1 > w - 1f || y0 > h - 1f || y1 > h - 1f) continue
            out.add(listOf(PointF(x0, y0), PointF(x1, y1)))
        }
        return out
    }

    private class CStroke(val comp: Int, val pts: List<PointF>)

    // تتبّع حلقات الحدود لكل منطقة على حدة وإغلاقها
    private fun traceLoops(bd: BooleanArray, cid: IntArray, w: Int, h: Int): List<CStroke> {
        val visited = BooleanArray(w * h)
        val out = ArrayList<CStroke>()
        val step = 2
        for (s in bd.indices) {
            if (!bd[s] || visited[s]) continue
            val comp = cid[s]
            val pts = ArrayList<Int>()
            var cur = s
            while (true) {
                visited[cur] = true
                pts.add(cur)
                val cx = cur % w
                val cy = cur / w
                var next = -1
                for (k in 0 until 8) {
                    val nx = cx + dxs[k]
                    val ny = cy + dys[k]
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val ni = ny * w + nx
                    if (bd[ni] && !visited[ni] && cid[ni] == comp) { next = ni; break }
                }
                if (next < 0) {
                    var bdist = Int.MAX_VALUE
                    for (dy in -2..2) for (dx in -2..2) {
                        val nx = cx + dx
                        val ny = cy + dy
                        if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                        val ni = ny * w + nx
                        if (bd[ni] && !visited[ni] && cid[ni] == comp) {
                            val dd = dx * dx + dy * dy
                            if (dd < bdist) { bdist = dd; next = ni }
                        }
                    }
                }
                if (next < 0) break
                cur = next
            }
            if (pts.size < 8) continue
            val res = ArrayList<PointF>()
            var j = 0
            while (j < pts.size) {
                res.add(PointF(pts[j] % w + 0.5f, pts[j] / w + 0.5f))
                j += step
            }
            val l = pts[pts.size - 1]
            res.add(PointF(l % w + 0.5f, l / w + 0.5f))
            // إغلاق الحلقة
            val f = pts[0]
            val dxl = (l % w) - (f % w)
            val dyl = (l / w) - (f / w)
            if (dxl * dxl + dyl * dyl <= 16) res.add(PointF(f % w + 0.5f, f / w + 0.5f))
            if (res.size >= 3) out.add(CStroke(comp, res))
        }
        return out
    }

    // ---------- الخلفية: لون الحافة المتصل بالحدود ----------
    private fun background(rr: IntArray, gg: IntArray, bb: IntArray, w: Int, h: Int, pockets: Boolean): BooleanArray {
        val n = w * h
        // لون الخلفية = اللون الأكثر تكراراً على الحافة (لا المتوسط، لأن الحافة قد تجمع سماء بيضاء وبحراً أزرق)
        val hist = IntArray(4096)
        fun add(i: Int) { hist[(rr[i] shr 4) * 256 + (gg[i] shr 4) * 16 + (bb[i] shr 4)]++ }
        for (x in 0 until w) { add(x); add((h - 1) * w + x) }
        for (y in 0 until h) { add(y * w); add(y * w + w - 1) }
        var bestKey = 0
        for (k in 1 until 4096) if (hist[k] > hist[bestKey]) bestKey = k
        var sr = 0L
        var sg = 0L
        var sb = 0L
        var cnt = 0L
        fun acc(i: Int) {
            if ((rr[i] shr 4) * 256 + (gg[i] shr 4) * 16 + (bb[i] shr 4) == bestKey) { sr += rr[i]; sg += gg[i]; sb += bb[i]; cnt++ }
        }
        for (x in 0 until w) { acc(x); acc((h - 1) * w + x) }
        for (y in 0 until h) { acc(y * w); acc(y * w + w - 1) }
        if (cnt == 0L) cnt = 1
        val mr = (sr / cnt).toInt()
        val mg = (sg / cnt).toInt()
        val mb = (sb / cnt).toInt()
        fun isBg(i: Int) = Math.abs(rr[i] - mr) + Math.abs(gg[i] - mg) + Math.abs(bb[i] - mb) < 45

        val bg = BooleanArray(n)
        val queue = IntArray(n)
        var head = 0
        var tail = 0
        fun push(i: Int) {
            if (!bg[i] && isBg(i)) { bg[i] = true; queue[tail++] = i }
        }
        for (x in 0 until w) { push(x); push((h - 1) * w + x) }
        for (y in 0 until h) { push(y * w); push(y * w + w - 1) }
        while (head < tail) {
            val i = queue[head++]
            val x = i % w
            val y = i / w
            if (x > 0) push(i - 1)
            if (x < w - 1) push(i + 1)
            if (y > 0) push(i - w)
            if (y < h - 1) push(i + w)
        }
        if (pockets) {
            // جيوب الخلفية المحصورة (داخل التاج، بين الذراع والجسم...): لونها يطابق الخلفية تقريباً ومساحتها كبيرة
            val seen = BooleanArray(n)
            val minPocket = Math.max(400, n / 3500)
            for (s in 0 until n) {
                if (bg[s] || seen[s]) continue
                if (Math.abs(rr[s] - mr) + Math.abs(gg[s] - mg) + Math.abs(bb[s] - mb) > 8) continue
                var hd = 0
                var tl = 0
                queue[tl++] = s
                seen[s] = true
                while (hd < tl) {
                    val i = queue[hd++]
                    val x = i % w
                    val y = i / w
                    if (x > 0 && !seen[i - 1] && !bg[i - 1] && Math.abs(rr[i - 1] - mr) + Math.abs(gg[i - 1] - mg) + Math.abs(bb[i - 1] - mb) <= 8) { seen[i - 1] = true; queue[tl++] = i - 1 }
                    if (x < w - 1 && !seen[i + 1] && !bg[i + 1] && Math.abs(rr[i + 1] - mr) + Math.abs(gg[i + 1] - mg) + Math.abs(bb[i + 1] - mb) <= 8) { seen[i + 1] = true; queue[tl++] = i + 1 }
                    if (y > 0 && !seen[i - w] && !bg[i - w] && Math.abs(rr[i - w] - mr) + Math.abs(gg[i - w] - mg) + Math.abs(bb[i - w] - mb) <= 8) { seen[i - w] = true; queue[tl++] = i - w }
                    if (y < h - 1 && !seen[i + w] && !bg[i + w] && Math.abs(rr[i + w] - mr) + Math.abs(gg[i + w] - mg) + Math.abs(bb[i + w] - mb) <= 8) { seen[i + w] = true; queue[tl++] = i + w }
                }
                if (tl >= minPocket) for (j in 0 until tl) bg[queue[j]] = true
            }
        }
        return bg
    }

    // ---------- تقليل الألوان (k-means) ----------
    private class Quant(val labels: IntArray, val centers: IntArray)

    // ---------- تكميم الألوان في فضاء Lab (أقرب لإدراك العين) مع k-means++ ----------
    private val lin = FloatArray(256) {
        val c = it / 255f
        if (c > 0.04045f) Math.pow(((c + 0.055f) / 1.055f).toDouble(), 2.4).toFloat() else c / 12.92f
    }

    private fun fLab(t: Float): Float =
        if (t > 0.008856f) Math.cbrt(t.toDouble()).toFloat() else 7.787f * t + 16f / 116f

    private fun toLab(r: Int, g: Int, b: Int, out: FloatArray, o: Int) {
        val rl = lin[r]
        val gl = lin[g]
        val bl = lin[b]
        val fx = fLab((0.4124f * rl + 0.3576f * gl + 0.1805f * bl) / 0.95047f)
        val fy = fLab(0.2126f * rl + 0.7152f * gl + 0.0722f * bl)
        val fz = fLab((0.0193f * rl + 0.1192f * gl + 0.9505f * bl) / 1.08883f)
        out[o] = 116f * fy - 16f
        out[o + 1] = 500f * (fx - fy)
        out[o + 2] = 200f * (fy - fz)
    }

    private fun quantize(rr: IntArray, gg: IntArray, bb: IntArray, valid: BooleanArray, k: Int): Quant {
        val n = rr.size
        var count = 0
        for (i in 0 until n) if (valid[i]) count++
        val labels = IntArray(n) { -1 }
        if (count == 0) return Quant(labels, IntArray(0))

        val lab = FloatArray(n * 3)
        for (i in 0 until n) if (valid[i]) toLab(rr[i], gg[i], bb[i], lab, i * 3)

        val stepS = Math.max(1, count / 40000)
        val idx = IntArray(count / stepS + 2)
        var m = 0
        var c = 0
        for (i in 0 until n) {
            if (!valid[i]) continue
            if (c % stepS == 0) idx[m++] = i
            c++
        }
        val kk = Math.min(k, m)
        val cl = FloatArray(kk * 3)
        val rnd = java.util.Random(7)
        val minD = FloatArray(m) { Float.MAX_VALUE }
        var first = idx[rnd.nextInt(m)]
        for (ci in 0 until kk) {
            if (ci > 0) {
                var total = 0.0
                for (s in 0 until m) {
                    val i = idx[s]
                    val dl = lab[i * 3] - cl[(ci - 1) * 3]
                    val da = lab[i * 3 + 1] - cl[(ci - 1) * 3 + 1]
                    val db = lab[i * 3 + 2] - cl[(ci - 1) * 3 + 2]
                    val d = dl * dl + da * da + db * db
                    if (d < minD[s]) minD[s] = d
                    total += minD[s]
                }
                var pick = rnd.nextDouble() * total
                var chosen = m - 1
                for (s in 0 until m) {
                    pick -= minD[s]
                    if (pick <= 0) { chosen = s; break }
                }
                first = idx[chosen]
            }
            cl[ci * 3] = lab[first * 3]; cl[ci * 3 + 1] = lab[first * 3 + 1]; cl[ci * 3 + 2] = lab[first * 3 + 2]
        }

        val sum = FloatArray(kk * 3)
        val cnt = IntArray(kk)
        for (iter in 0 until 10) {
            java.util.Arrays.fill(sum, 0f)
            java.util.Arrays.fill(cnt, 0)
            for (s in 0 until m) {
                val i = idx[s]
                val l = lab[i * 3]
                val a = lab[i * 3 + 1]
                val b = lab[i * 3 + 2]
                var bi = 0
                var bd = Float.MAX_VALUE
                for (ci in 0 until kk) {
                    val dl = l - cl[ci * 3]
                    val da = a - cl[ci * 3 + 1]
                    val db = b - cl[ci * 3 + 2]
                    val d = dl * dl + da * da + db * db
                    if (d < bd) { bd = d; bi = ci }
                }
                sum[bi * 3] += l; sum[bi * 3 + 1] += a; sum[bi * 3 + 2] += b; cnt[bi]++
            }
            for (ci in 0 until kk) if (cnt[ci] > 0) {
                cl[ci * 3] = sum[ci * 3] / cnt[ci]
                cl[ci * 3 + 1] = sum[ci * 3 + 1] / cnt[ci]
                cl[ci * 3 + 2] = sum[ci * 3 + 2] / cnt[ci]
            }
        }

        val lr = LongArray(kk)
        val lg = LongArray(kk)
        val lbb = LongArray(kk)
        val lc = LongArray(kk)
        for (i in 0 until n) {
            if (!valid[i]) continue
            val l = lab[i * 3]
            val a = lab[i * 3 + 1]
            val b = lab[i * 3 + 2]
            var bi = 0
            var bd = Float.MAX_VALUE
            for (ci in 0 until kk) {
                val dl = l - cl[ci * 3]
                val da = a - cl[ci * 3 + 1]
                val db = b - cl[ci * 3 + 2]
                val d = dl * dl + da * da + db * db
                if (d < bd) { bd = d; bi = ci }
            }
            labels[i] = bi
            lr[bi] += rr[i].toLong(); lg[bi] += gg[i].toLong(); lbb[bi] += bb[i].toLong(); lc[bi]++
        }
        val centers = IntArray(kk)
        for (ci in 0 until kk) {
            centers[ci] = if (lc[ci] > 0)
                Color.rgb((lr[ci] / lc[ci]).toInt(), (lg[ci] / lc[ci]).toInt(), (lbb[ci] / lc[ci]).toInt())
            else Color.rgb(255, 255, 255)
        }
        return Quant(labels, centers)
    }

    // دمج الألوان المتقاربة جداً (المسافة في Lab)
    private fun mergeClose(q: Quant, n: Int, thr: Int): Quant {
        val k = q.centers.size
        if (k <= 1) return q
        val area = IntArray(k)
        for (i in 0 until n) if (q.labels[i] >= 0) area[q.labels[i]]++
        val cr = IntArray(k) { Color.red(q.centers[it]) }
        val cg = IntArray(k) { Color.green(q.centers[it]) }
        val cb = IntArray(k) { Color.blue(q.centers[it]) }
        val lab = FloatArray(k * 3)
        for (i in 0 until k) toLab(cr[i], cg[i], cb[i], lab, i * 3)
        val parent = IntArray(k) { it }
        fun find(x: Int): Int {
            var a = x
            while (parent[a] != a) a = parent[a]
            return a
        }
        val lim = (thr * thr).toFloat()
        while (true) {
            var bi = -1
            var bj = -1
            var bd = Float.MAX_VALUE
            for (i in 0 until k) {
                if (parent[i] != i) continue
                for (j in i + 1 until k) {
                    if (parent[j] != j) continue
                    val dl = lab[i * 3] - lab[j * 3]
                    val da = lab[i * 3 + 1] - lab[j * 3 + 1]
                    val db = lab[i * 3 + 2] - lab[j * 3 + 2]
                    val d = dl * dl + da * da + db * db
                    if (d < bd) { bd = d; bi = i; bj = j }
                }
            }
            if (bi < 0 || bd > lim) break
            val big = if (area[bi] >= area[bj]) bi else bj
            val small = if (big == bi) bj else bi
            val tot = area[big] + area[small]
            if (tot > 0) {
                cr[big] = ((cr[big].toLong() * area[big] + cr[small].toLong() * area[small]) / tot).toInt()
                cg[big] = ((cg[big].toLong() * area[big] + cg[small].toLong() * area[small]) / tot).toInt()
                cb[big] = ((cb[big].toLong() * area[big] + cb[small].toLong() * area[small]) / tot).toInt()
                toLab(cr[big], cg[big], cb[big], lab, big * 3)
            }
            area[big] = tot
            area[small] = 0
            parent[small] = big
        }
        val newIdx = IntArray(k) { -1 }
        var m = 0
        for (i in 0 until k) if (parent[i] == i) newIdx[i] = m++
        val centers = IntArray(m)
        for (i in 0 until k) if (parent[i] == i) centers[newIdx[i]] = Color.rgb(cr[i], cg[i], cb[i])
        val labels = IntArray(n) { -1 }
        for (i in 0 until n) {
            val l = q.labels[i]
            if (l >= 0) labels[i] = newIdx[find(l)]
        }
        return Quant(labels, centers)
    }

    private fun smooth(labels: IntArray, w: Int, h: Int, k: Int, r: Int = 1): IntArray {
        val out = labels.copyOf()
        val cnt = IntArray(k)
        for (y in r until h - r) {
            for (x in r until w - r) {
                val i = y * w + x
                val cur = labels[i]
                if (cur < 0) continue
                java.util.Arrays.fill(cnt, 0)
                for (dy in -r..r) for (dx in -r..r) {
                    val l = labels[i + dy * w + dx]
                    if (l >= 0) cnt[l]++
                }
                var best = cur
                var bc = cnt[cur]
                for (l in 0 until k) if (cnt[l] > bc) { bc = cnt[l]; best = l }
                out[i] = best
            }
        }
        return out
    }

    // توسيع الألوان تحت خطوط الحدود حتى لا تبقى فجوات
    private fun spread(labels: IntArray, bg: BooleanArray, w: Int, h: Int) {
        val n = w * h
        val queue = IntArray(n)
        var head = 0
        var tail = 0
        for (i in 0 until n) if (labels[i] >= 0) queue[tail++] = i
        while (head < tail) {
            val i = queue[head++]
            val x = i % w
            val y = i / w
            val l = labels[i]
            if (x > 0 && labels[i - 1] < 0 && !bg[i - 1]) { labels[i - 1] = l; queue[tail++] = i - 1 }
            if (x < w - 1 && labels[i + 1] < 0 && !bg[i + 1]) { labels[i + 1] = l; queue[tail++] = i + 1 }
            if (y > 0 && labels[i - w] < 0 && !bg[i - w]) { labels[i - w] = l; queue[tail++] = i - w }
            if (y < h - 1 && labels[i + w] < 0 && !bg[i + w]) { labels[i + w] = l; queue[tail++] = i + w }
        }
    }

    // نقطة داخل منطقة اللون (أطول مقطع أفقي له دعم عمودي) لأخذ اللون بالقطّارة
    private fun pickPoint(labels: IntArray, lab: Int, w: Int, h: Int): PointF {
        var bestLen = -1
        var bx = -1
        var by = -1
        var y = 4
        while (y < h - 4) {
            var x = 0
            while (x < w) {
                if (labels[y * w + x] == lab) {
                    val s = x
                    while (x < w && labels[y * w + x] == lab) x++
                    val len = x - s
                    if (len > bestLen) {
                        val mx = (s + x - 1) / 2
                        if (labels[(y - 4) * w + mx] == lab && labels[(y + 4) * w + mx] == lab) {
                            bestLen = len; bx = mx; by = y
                        }
                    }
                } else {
                    x++
                }
            }
            y += 2
        }
        if (bx < 0) {
            for (i in labels.indices) if (labels[i] == lab) { bx = i % w; by = i / w; break }
        }
        return PointF(bx + 0.5f, by + 0.5f)
    }

    // ---------- تلوين متعرّج (serpentine) لمنطقة لون واحد ----------
    private fun scribble(labels: IntArray, lab: Int, w: Int, h: Int, gap: Int): List<List<PointF>> {
        val ys = ArrayList<Int>()
        val rows = ArrayList<ArrayList<IntArray>>()
        var y = gap / 2 + 1
        while (y < h - 1) {
            val runs = ArrayList<IntArray>()
            var x = 0
            while (x < w) {
                if (labels[y * w + x] == lab) {
                    val s = x
                    while (x < w && labels[y * w + x] == lab) x++
                    if (x - s >= 3) runs.add(intArrayOf(Math.max(0, s - 1), Math.min(w - 1, x), 0))
                } else {
                    x++
                }
            }
            ys.add(y)
            rows.add(runs)
            y += gap
        }

        if (!snakeMode) {
            // خطوط مستقيمة منفصلة: تتحمل سرعة الرسم العالية دون تقصير الزوايا
            val o = ArrayList<List<PointF>>()
            for (ri in rows.indices) for (run in rows[ri]) {
                o.add(listOf(PointF(run[0] + 0.5f, ys[ri] + 0.5f), PointF(run[1] + 0.5f, ys[ri] + 0.5f)))
            }
            return o
        }
        val out = ArrayList<List<PointF>>()
        val maxJump = 2 * gap + 2
        for (ri in rows.indices) {
            for (run in rows[ri]) {
                if (run[2] == 1) continue
                run[2] = 1
                val pts = ArrayList<PointF>()
                var lr = true
                pts.add(PointF(run[0] + 0.5f, ys[ri] + 0.5f))
                pts.add(PointF(run[1] + 0.5f, ys[ri] + 0.5f))
                var cur = run
                var r = ri
                while (r + 1 < rows.size && pts.size < 300) {
                    val endX = if (lr) cur[1] else cur[0]
                    var found: IntArray? = null
                    var startAtLeft = true
                    for (cand in rows[r + 1]) {
                        if (cand[2] == 1) continue
                        if (cand[0] > cur[1] || cand[1] < cur[0]) continue
                        val dl = Math.abs(endX - cand[0])
                        val dr = Math.abs(endX - cand[1])
                        val sx = if (dl <= dr) cand[0] else cand[1]
                        if (Math.abs(endX - sx) <= maxJump) {
                            found = cand
                            startAtLeft = dl <= dr
                            break
                        }
                    }
                    if (found == null) break
                    found[2] = 1
                    r++
                    val yy = ys[r] + 0.5f
                    if (startAtLeft) {
                        pts.add(PointF(found[0] + 0.5f, yy))
                        pts.add(PointF(found[1] + 0.5f, yy))
                        lr = true
                    } else {
                        pts.add(PointF(found[1] + 0.5f, yy))
                        pts.add(PointF(found[0] + 0.5f, yy))
                        lr = false
                    }
                    cur = found
                }
                out.add(pts)
            }
        }
        return out
    }

    // تعبئة المساحات الداكنة في وضع الخطوط فقط
    private fun hatch(region: BooleanArray, w: Int, h: Int, gap: Int): List<List<PointF>> {
        val out = ArrayList<List<PointF>>()
        var rowIdx = 0
        var y = gap / 2 + 1
        while (y < h - 1) {
            val runs = ArrayList<IntArray>()
            var x = 0
            while (x < w) {
                if (region[y * w + x]) {
                    val s = x
                    while (x < w && region[y * w + x]) x++
                    if (x - s >= 3) runs.add(intArrayOf(s, x - 1))
                } else {
                    x++
                }
            }
            if (rowIdx % 2 == 1) runs.reverse()
            for (r in runs) {
                val a = PointF(r[0] + 0.5f, y + 0.5f)
                val b = PointF(r[1] + 0.5f, y + 0.5f)
                out.add(if (rowIdx % 2 == 0) listOf(a, b) else listOf(b, a))
            }
            rowIdx++
            y += gap
        }
        return out
    }

    // ---------- Zhang-Suen ----------
    private fun thin(img: BooleanArray, w: Int, h: Int) {
        val del = IntArray(w * h)
        var changed = true
        while (changed) {
            changed = false
            for (step in 0..1) {
                var cnt = 0
                for (y in 1 until h - 1) {
                    for (x in 1 until w - 1) {
                        val i = y * w + x
                        if (!img[i]) continue
                        val p2 = img[i - w]
                        val p3 = img[i - w + 1]
                        val p4 = img[i + 1]
                        val p5 = img[i + w + 1]
                        val p6 = img[i + w]
                        val p7 = img[i + w - 1]
                        val p8 = img[i - 1]
                        val p9 = img[i - w - 1]
                        var nn = 0
                        if (p2) nn++
                        if (p3) nn++
                        if (p4) nn++
                        if (p5) nn++
                        if (p6) nn++
                        if (p7) nn++
                        if (p8) nn++
                        if (p9) nn++
                        if (nn < 2 || nn > 6) continue
                        var a = 0
                        if (!p2 && p3) a++
                        if (!p3 && p4) a++
                        if (!p4 && p5) a++
                        if (!p5 && p6) a++
                        if (!p6 && p7) a++
                        if (!p7 && p8) a++
                        if (!p8 && p9) a++
                        if (!p9 && p2) a++
                        if (a != 1) continue
                        if (step == 0) {
                            if (p2 && p4 && p6) continue
                            if (p4 && p6 && p8) continue
                        } else {
                            if (p2 && p4 && p8) continue
                            if (p2 && p6 && p8) continue
                        }
                        del[cnt++] = i
                    }
                }
                if (cnt > 0) {
                    changed = true
                    for (q in 0 until cnt) img[del[q]] = false
                }
            }
        }
    }

    private val dxs = intArrayOf(1, -1, 0, 0, 1, 1, -1, -1)
    private val dys = intArrayOf(0, 0, 1, -1, 1, -1, 1, -1)

    private fun trace(sk: BooleanArray, w: Int, h: Int): List<List<PointF>> {
        val visited = BooleanArray(w * h)
        val out = ArrayList<List<PointF>>()
        val step = 2
        val minPts = 12

        fun neighborCount(i: Int): Int {
            val x = i % w
            val y = i / w
            var c = 0
            for (k in 0 until 8) {
                val nx = x + dxs[k]
                val ny = y + dys[k]
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                if (sk[ny * w + nx]) c++
            }
            return c
        }

        fun walk(start: Int) {
            val pts = ArrayList<Int>()
            var cur = start
            while (true) {
                visited[cur] = true
                pts.add(cur)
                val cx = cur % w
                val cy = cur / w
                var next = -1
                for (k in 0 until 8) {
                    val nx = cx + dxs[k]
                    val ny = cy + dys[k]
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val ni = ny * w + nx
                    if (sk[ni] && !visited[ni]) { next = ni; break }
                }
                if (next < 0) break
                cur = next
            }
            if (pts.size < minPts) return
            val res = ArrayList<PointF>()
            var k = 0
            while (k < pts.size) {
                res.add(PointF(pts[k] % w + 0.5f, pts[k] / w + 0.5f))
                k += step
            }
            if ((pts.size - 1) % step != 0) {
                val l = pts[pts.size - 1]
                res.add(PointF(l % w + 0.5f, l / w + 0.5f))
            }
            if (res.size >= 2) out.add(res)
        }

        for (i in sk.indices) if (sk[i] && !visited[i] && neighborCount(i) <= 1) walk(i)
        for (i in sk.indices) if (sk[i] && !visited[i]) walk(i)
        return out
    }
}
