package com.sketchbot.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private var bitmap: Bitmap? = null
    private var loaded: Tracer.Loaded? = null
    private var threshold = 55
    private var detail = 40
    private var brushPx = 3
    private var colors = 36
    private var fillMode = false
    private var soft = 0
    private var blend = false
    private var pockets = true
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var thLabel: TextView
    private lateinit var dtLabel: TextView
    private lateinit var fgLabel: TextView
    private lateinit var clLabel: TextView

    private fun label() = TextView(this).apply {
        gravity = Gravity.CENTER
        setTextColor(Ui.TEXT)
        textSize = 13.5f
        typeface = Ui.medium()
    }

    private fun glassCard(d: Float, strength: Float = 1f) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GlassDrawable(22f, d, strength)
        setPadding((16 * d).toInt(), (14 * d).toInt(), (16 * d).toInt(), (14 * d).toInt())
    }

    private fun styleSeek(s: SeekBar) {
        s.progressTintList = ColorStateList.valueOf(Ui.C2)
        s.progressBackgroundTintList = ColorStateList.valueOf(Ui.alpha(Color.WHITE, 0x40))
        s.thumbTintList = ColorStateList.valueOf(Color.WHITE)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        val title = GradientText(this).apply {
            text = "MR NEGROO"
            textSize = 30f
            typeface = Ui.black()
            letterSpacing = 0.16f
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "SKETCH STUDIO  ·  رسم تلقائي احترافي"
            setTextColor(Ui.SUB)
            textSize = 12f
            letterSpacing = 0.08f
            gravity = Gravity.CENTER
            typeface = Ui.medium()
        }

        val steps = glassCard(d).apply {
            addView(TextView(this@MainActivity).apply {
                text = "1  فعّل الخدمة ثم اختر الصورة وراجع المعاينة\n" +
                    "2  في Sketchbook كبّر الكانفس واختر فرشاة Fine Tip صغيرة\n" +
                    "3  من الشريط العائم: حدّد المنطقة، ثم علّم اللون والفرشاة (مرة واحدة)\n" +
                    "4  اضغط قياس الفرشاة ثم ابدأ"
                setTextColor(Ui.SUB)
                textSize = 12.5f
                setLineSpacing(0f, 1.25f)
            })
        }

        val btnAcc = GlassButton(this, Ic.POWER, "تفعيل الخدمة")
        val btnPick = GlassButton(this, Ic.IMAGE, "اختيار صورة", accent = true)
        val btnMode = GlassButton(this, Ic.BRUSH, "التلوين: فرشاة دقيقة (اضغط للتبديل)")
        val btnPock = GlassButton(this, Ic.PIZZA, "البياض المحصور: خلفية (اضغط للتبديل)")
        val btnLayers = GlassButton(this, Ic.LAYERS, "الطبقات: طبقة لكل لون (اضغط للتبديل)")

        thLabel = label().apply { text = "سواد الخطوط: $threshold" }
        val seekTh = SeekBar(this).apply { max = 120; progress = threshold - 20 }
        dtLabel = label().apply { text = "تفاصيل الخطوط: $detail" }
        val seekDt = SeekBar(this).apply { max = 100; progress = detail }
        clLabel = label().apply { text = "عدد الألوان: $colors (0 = بدون تلوين)" }
        val seekCl = SeekBar(this).apply { max = 64; progress = colors }
        fgLabel = label().apply { text = "سمك الفرشاة: $brushPx (كلما قلّ زادت الدقة والوقت)" }
        val seekFg = SeekBar(this).apply { max = 19; progress = brushPx - 1 }
        val spLabel = label().apply { text = "سرعة الرسم: ×${Shared.speed.toInt()} (لا تؤثر على سرعة تغيير الألوان)" }
        val seekSp = SeekBar(this).apply { max = 9; progress = Shared.speed.toInt() - 1 }
        for (s in listOf(seekTh, seekDt, seekCl, seekFg, seekSp)) styleSeek(s)

        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.parseColor("#F7F7FB"))
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, 18 * d) }
            }
            clipToOutline = true
        }
        status = label().apply {
            text = "لم تُختر صورة بعد"
            textSize = 12.5f
            setTextColor(Ui.SUB)
        }
        val previewCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GlassDrawable(24f, d, 1.2f)
            setPadding((8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
            addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (400 * d).toInt()))
        }
        val settings = glassCard(d).apply {
            fun gap() = View(this@MainActivity).also { addView(it, LinearLayout.LayoutParams(1, (6 * d).toInt())) }
            addView(btnMode); gap()
            addView(btnPock); gap()
            addView(btnLayers); gap(); gap()
            addView(thLabel); addView(seekTh)
            addView(dtLabel); addView(seekDt)
            addView(clLabel); addView(seekCl)
            addView(fgLabel); addView(seekFg)
            addView(spLabel); addView(seekSp)
        }

        fun lp(top: Int) = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = (top * d).toInt() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((18 * d).toInt(), (44 * d).toInt(), (18 * d).toInt(), (28 * d).toInt())
            addView(title, lp(0))
            addView(subtitle, lp(4))
            addView(steps, lp(18))
            addView(btnAcc, lp(14))
            addView(btnPick, lp(10))
            addView(previewCard, lp(14))
            addView(status, lp(8))
            addView(settings, lp(14))
        }

        val frame = FrameLayout(this)
        frame.addView(AuroraView(this), FrameLayout.LayoutParams(-1, -1))
        frame.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(root) }, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)

        if (b == null) {
            var sp: View? = null
            sp = SplashView(this) { sp?.let { v -> frame.post { frame.removeView(v) } } }
            frame.addView(sp, FrameLayout.LayoutParams(-1, -1))
        }

        btnAcc.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnPick.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(i, "اختر صورة"), 1)
        }
        btnPock.setOnClickListener {
            pockets = !pockets
            btnPock.text = if (pockets) "البياض المحصور: خلفية (اضغط للتبديل)" else "البياض المحصور: يُرسم أبيض (اضغط للتبديل)"
            process()
        }
        btnLayers.setOnClickListener {
            Shared.layers = !Shared.layers
            btnLayers.text = if (Shared.layers) "الطبقات: طبقة لكل لون (اضغط للتبديل)" else "الطبقات: طبقة واحدة (اضغط للتبديل)"
        }
        btnMode.setOnClickListener {
            fillMode = !fillMode
            btnMode.text = if (fillMode) "التلوين: تعبئة Fill (اضغط للتبديل)" else "التلوين: فرشاة دقيقة (اضغط للتبديل)"
            process()
        }

        fun bind(seek: SeekBar, onChange: (Int) -> Unit) {
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { process() }
            })
        }
        bind(seekTh) { p -> threshold = 20 + p; thLabel.text = "سواد الخطوط: $threshold" }
        bind(seekDt) { p -> detail = p; dtLabel.text = "تفاصيل الخطوط: $detail" }
        bind(seekCl) { p -> colors = p; clLabel.text = "عدد الألوان: $colors (0 = بدون تلوين)" }
        seekSp.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                Shared.speed = (1 + p).toFloat()
                spLabel.text = "سرعة الرسم: ×${1 + p} (لا تؤثر على سرعة تغيير الألوان)"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { process() }
        })
        bind(seekFg) { p -> getSharedPreferences("sb", MODE_PRIVATE).edit().remove("brushScreen").apply(); brushPx = 1 + p; fgLabel.text = "سمك الفرشاة: $brushPx (كلما قلّ زادت الدقة والوقت)" }
    }

    override fun onResume() {
        super.onResume()
        if (bitmap != null) process()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            status.text = "جاري تحميل الصورة..."
            thread {
                val ld = Tracer.load(this, uri, 1500)
                runOnUiThread {
                    if (ld == null) {
                        status.text = "تعذّر فتح الصورة"
                    } else {
                        bitmap = ld.bmp
                        loaded = ld
                        process()
                    }
                }
            }
        }
    }

    // كم بكسل على الشاشة يساوي بكسل واحد من الصورة المحلَّلة (حسب منطقة الرسم المحفوظة)
    private fun screenScale(bmp: Bitmap): Float {
        val p = getSharedPreferences("sb", MODE_PRIVATE)
        var rw = resources.displayMetrics.widthPixels * 0.9f
        var rh = resources.displayMetrics.heightPixels * 0.7f
        if (p.contains("l")) {
            rw = p.getFloat("r", 0f) - p.getFloat("l", 0f)
            rh = p.getFloat("b", 0f) - p.getFloat("t", 0f)
        }
        val s = Math.min(rw / bmp.width, rh / bmp.height)
        return Math.max(0.05f, s)
    }

    private fun process() {
        val bmp = bitmap ?: return
        val ld = loaded ?: return
        status.text = "جاري تحليل الصورة..."
        val t = threshold
        val dt = detail
        val sc = screenScale(bmp)
        val measured = getSharedPreferences("sb", MODE_PRIVATE).getFloat("brushScreen", 0f)
        val eff = if (measured > 0f) measured else brushPx.toFloat()
        val fg = Math.max(1, Math.round(eff * 0.6f / sc))
        val cl = colors
        val fm = fillMode
        val sf = soft
        val bl = blend
        val pk = pockets
        val sn = Shared.speed <= 2f
        thread {
            try {
                val r = Tracer.process(bmp, t, dt, fg, cl, fm, sf, bl, sn, pk)
                runOnUiThread {
                    Shared.phases = r.phases
                    Shared.imgW = r.w
                    Shared.imgH = r.h
                    Shared.fx0 = ld.fx0
                    Shared.fy0 = ld.fy0
                    Shared.fw = ld.fw
                    Shared.fh = ld.fh
                    Shared.aspect = ld.aspect
                    preview.setImageBitmap(r.preview)
                    var total = 0
                    for (p in r.phases) total += p.strokes.size
                    val want = r.lineThick * sc
                    val mb = getSharedPreferences("sb", MODE_PRIVATE).getFloat("brushScreen", 0f)
                    val rec = if (want > 0f) {
                        " | سمك الخطوط الأصلي ≈ ${"%.1f".format(want)} بكسل" +
                            (if (mb > 0f) " | فرشاتك المقاسة = ${mb.toInt()} بكسل" +
                                (if (mb > want * 1.4f) ": كبيرة، صغّر Size إلى ${"%.0f".format(100f * want / mb)}% تقريباً" else ": مناسبة")
                            else " | قِس فرشاتك بزر 📏")
                    } else ""
                    status.text = "جاهز: ${r.phases.size} مرحلة، $total خط$rec"
                }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "خطأ في التحليل: ${e.message}" }
            }
        }
    }
}
